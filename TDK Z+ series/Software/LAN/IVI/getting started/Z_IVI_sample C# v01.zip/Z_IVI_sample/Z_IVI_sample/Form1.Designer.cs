﻿namespace Z_IVI_sample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.InitButton = new System.Windows.Forms.Button();
            this.InitLabel = new System.Windows.Forms.Label();
            this.ToggleOutButton = new System.Windows.Forms.Button();
            this.ProgVoltButton = new System.Windows.Forms.Button();
            this.MeasVoltButton = new System.Windows.Forms.Button();
            this.ProgVoltTextBox = new System.Windows.Forms.TextBox();
            this.MeasVoltTextBox = new System.Windows.Forms.TextBox();
            this.ProgVoltLabel = new System.Windows.Forms.Label();
            this.MeasVoltLabel = new System.Windows.Forms.Label();
            this.CloseButton = new System.Windows.Forms.Button();
            this.ApplyButton = new System.Windows.Forms.Button();
            this.IPTextBox = new System.Windows.Forms.TextBox();
            this.IpAddrLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // InitButton
            // 
            this.InitButton.Location = new System.Drawing.Point(264, 36);
            this.InitButton.Name = "InitButton";
            this.InitButton.Size = new System.Drawing.Size(75, 23);
            this.InitButton.TabIndex = 0;
            this.InitButton.Text = "Initialize";
            this.InitButton.UseVisualStyleBackColor = true;
            this.InitButton.Click += new System.EventHandler(this.InitButton_Click);
            // 
            // InitLabel
            // 
            this.InitLabel.AutoSize = true;
            this.InitLabel.Location = new System.Drawing.Point(104, 41);
            this.InitLabel.Name = "InitLabel";
            this.InitLabel.Size = new System.Drawing.Size(133, 13);
            this.InitLabel.TabIndex = 1;
            this.InitLabel.Text = "IP Address = 169.254.7.53";
            // 
            // ToggleOutButton
            // 
            this.ToggleOutButton.Location = new System.Drawing.Point(149, 106);
            this.ToggleOutButton.Name = "ToggleOutButton";
            this.ToggleOutButton.Size = new System.Drawing.Size(157, 23);
            this.ToggleOutButton.TabIndex = 5;
            this.ToggleOutButton.Text = "Toggle Output On/Off";
            this.ToggleOutButton.UseVisualStyleBackColor = true;
            this.ToggleOutButton.Click += new System.EventHandler(this.ToggleOutButton_Click);
            // 
            // ProgVoltButton
            // 
            this.ProgVoltButton.Location = new System.Drawing.Point(212, 147);
            this.ProgVoltButton.Name = "ProgVoltButton";
            this.ProgVoltButton.Size = new System.Drawing.Size(75, 23);
            this.ProgVoltButton.TabIndex = 6;
            this.ProgVoltButton.Text = "Send";
            this.ProgVoltButton.UseVisualStyleBackColor = true;
            this.ProgVoltButton.Click += new System.EventHandler(this.ProgVoltButton_Click);
            // 
            // MeasVoltButton
            // 
            this.MeasVoltButton.Location = new System.Drawing.Point(212, 176);
            this.MeasVoltButton.Name = "MeasVoltButton";
            this.MeasVoltButton.Size = new System.Drawing.Size(75, 23);
            this.MeasVoltButton.TabIndex = 7;
            this.MeasVoltButton.Text = "Read";
            this.MeasVoltButton.UseVisualStyleBackColor = true;
            this.MeasVoltButton.Click += new System.EventHandler(this.MeasVoltButton_Click);
            // 
            // ProgVoltTextBox
            // 
            this.ProgVoltTextBox.Location = new System.Drawing.Point(136, 149);
            this.ProgVoltTextBox.Name = "ProgVoltTextBox";
            this.ProgVoltTextBox.Size = new System.Drawing.Size(54, 20);
            this.ProgVoltTextBox.TabIndex = 8;
            this.ProgVoltTextBox.Text = "0.0";
            // 
            // MeasVoltTextBox
            // 
            this.MeasVoltTextBox.Location = new System.Drawing.Point(136, 176);
            this.MeasVoltTextBox.Name = "MeasVoltTextBox";
            this.MeasVoltTextBox.Size = new System.Drawing.Size(54, 20);
            this.MeasVoltTextBox.TabIndex = 9;
            this.MeasVoltTextBox.Text = "0.0";
            // 
            // ProgVoltLabel
            // 
            this.ProgVoltLabel.AutoSize = true;
            this.ProgVoltLabel.Location = new System.Drawing.Point(43, 152);
            this.ProgVoltLabel.Name = "ProgVoltLabel";
            this.ProgVoltLabel.Size = new System.Drawing.Size(85, 13);
            this.ProgVoltLabel.TabIndex = 10;
            this.ProgVoltLabel.Text = "Program Voltage";
            // 
            // MeasVoltLabel
            // 
            this.MeasVoltLabel.AutoSize = true;
            this.MeasVoltLabel.Location = new System.Drawing.Point(43, 181);
            this.MeasVoltLabel.Name = "MeasVoltLabel";
            this.MeasVoltLabel.Size = new System.Drawing.Size(87, 13);
            this.MeasVoltLabel.TabIndex = 11;
            this.MeasVoltLabel.Text = "Measure Voltage";
            // 
            // CloseButton
            // 
            this.CloseButton.Location = new System.Drawing.Point(149, 217);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(157, 23);
            this.CloseButton.TabIndex = 12;
            this.CloseButton.Text = "Close";
            this.CloseButton.UseVisualStyleBackColor = true;
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // ApplyButton
            // 
            this.ApplyButton.Location = new System.Drawing.Point(264, 64);
            this.ApplyButton.Name = "ApplyButton";
            this.ApplyButton.Size = new System.Drawing.Size(75, 23);
            this.ApplyButton.TabIndex = 2;
            this.ApplyButton.Text = "Apply";
            this.ApplyButton.UseVisualStyleBackColor = true;
            this.ApplyButton.Click += new System.EventHandler(this.ApplyButton_Click);
            // 
            // IPTextBox
            // 
            this.IPTextBox.Location = new System.Drawing.Point(107, 67);
            this.IPTextBox.Name = "IPTextBox";
            this.IPTextBox.Size = new System.Drawing.Size(151, 20);
            this.IPTextBox.TabIndex = 3;
            this.IPTextBox.Text = "169.254.7.53";
            // 
            // IpAddrLabel
            // 
            this.IpAddrLabel.AutoSize = true;
            this.IpAddrLabel.Location = new System.Drawing.Point(43, 70);
            this.IpAddrLabel.Name = "IpAddrLabel";
            this.IpAddrLabel.Size = new System.Drawing.Size(58, 13);
            this.IpAddrLabel.TabIndex = 4;
            this.IpAddrLabel.Text = "IP Address";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 262);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.MeasVoltLabel);
            this.Controls.Add(this.ProgVoltLabel);
            this.Controls.Add(this.MeasVoltTextBox);
            this.Controls.Add(this.ProgVoltTextBox);
            this.Controls.Add(this.MeasVoltButton);
            this.Controls.Add(this.ProgVoltButton);
            this.Controls.Add(this.ToggleOutButton);
            this.Controls.Add(this.IpAddrLabel);
            this.Controls.Add(this.IPTextBox);
            this.Controls.Add(this.ApplyButton);
            this.Controls.Add(this.InitLabel);
            this.Controls.Add(this.InitButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button InitButton;
        private System.Windows.Forms.Label InitLabel;
        private System.Windows.Forms.Button ToggleOutButton;
        private System.Windows.Forms.Button ProgVoltButton;
        private System.Windows.Forms.Button MeasVoltButton;
        private System.Windows.Forms.TextBox ProgVoltTextBox;
        private System.Windows.Forms.TextBox MeasVoltTextBox;
        private System.Windows.Forms.Label ProgVoltLabel;
        private System.Windows.Forms.Label MeasVoltLabel;
        private System.Windows.Forms.Button CloseButton;
        private System.Windows.Forms.Button ApplyButton;
        private System.Windows.Forms.TextBox IPTextBox;
        private System.Windows.Forms.Label IpAddrLabel;
    }
}

