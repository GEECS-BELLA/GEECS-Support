﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

//For creating an instance of the Z plus IVI driver
using Lambda.LambdaZPlus.Interop;

//For defining an error COMExeption class just for instruments
using System.Runtime.InteropServices;

namespace Z_IVI_sample
{
    public partial class Form1 : Form
    {
        LambdaZPlus ZplIvi;         //Declaration ZplIvi driver object
        string IpAddr = "TCPIP::169.254.7.53::INSTR";              //saved power supply adress

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void InitButton_Click(object sender, EventArgs e)
        {
            //Clicked the button to inilize the connection to
            //a power supply 
            ZplIvi = new LambdaZPlus();

            try
            {
                ZplIvi.Initialize(IpAddr, false, false, "QueryInstrStatus = true");
            }
            // COMExeption not used here, because the LAN connection have
            // not been made to the power supply to read it's error
            catch (Exception ex)
            {
                MessageBox.Show("Initialization Error: " + ex.Message);
            }

            //Enable Error loging
            try
            {
                ZplIvi.System.DirectIO.WriteString("syst:err:enab");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Logging Error: " + ex.Message);
            }

            
        }

        private void ApplyButton_Click(object sender, EventArgs e)
        {
            IpAddr = "TCPIP::" + IPTextBox.Text + "::INSTR";   
            InitLabel.Text = "IP address = " + IPTextBox.Text;
        }

        private void ToggleOutButton_Click(object sender, EventArgs e)
        {
            //Clicked the button to toggle the output ON or OFF
            try
            {
                Boolean OutState;
                OutState = ZplIvi.Output.Enabled;
                ZplIvi.Output.Enabled = !OutState;
            }
            catch (COMException)
            {
                Int32 ErrorCode = 0;
                String ErrorMessage = "";

                ZplIvi.Utility.ErrorQuery(ref ErrorCode, ref ErrorMessage);

                MessageBox.Show("Toggle Output Error: " + ErrorCode + ", " + ErrorMessage);
            }
        }

        private void ProgVoltButton_Click(object sender, EventArgs e)
        {
            //Clicked the button send a new program voltage value
            try
            {
                ZplIvi.Voltage.Level = Double.Parse(ProgVoltTextBox.Text);
            }

            catch (COMException)
            {
                Int32 ErrorCode = 0;
                String ErrorMessage = "";

                ZplIvi.Utility.ErrorQuery(ref ErrorCode, ref ErrorMessage);

                MessageBox.Show("Program voltage Error: " + ErrorCode + ", " + ErrorMessage);
            }
        }

        private void MeasVoltButton_Click(object sender, EventArgs e)
        {
            //Clicked the button read the output voltage value
            try
            {
                MeasVoltTextBox.Text = Convert.ToString(ZplIvi.Voltage.Level);
            }
            //COMExeption not used here, because a measurement querry
            //cannot return an error if querry syntax is correct
            catch (Exception ex)
            {
                MessageBox.Show("Measure Voltage Error: " + ex.Message);
            }
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            //Clicked the button close the connection
            if (ZplIvi.Initialized)//if connection was open, than close it
            {
                try
                {
                    ZplIvi.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Close Error: " + ex.Message);
                }
            }
        }
    }
}
